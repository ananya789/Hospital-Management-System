<?php
echo "Test file loaded successfully";
?>
